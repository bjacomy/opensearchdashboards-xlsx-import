"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'opensearchdashboardsXlsxImport';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'opensearchdashboards-xlsx-import';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIlBMVUdJTl9JRCIsIlBMVUdJTl9OQU1FIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBTyxNQUFNQSxTQUFTLEdBQUcsZ0NBQWxCOztBQUNBLE1BQU1DLFdBQVcsR0FBRyxrQ0FBcEIiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgUExVR0lOX0lEID0gJ29wZW5zZWFyY2hkYXNoYm9hcmRzWGxzeEltcG9ydCc7XG5leHBvcnQgY29uc3QgUExVR0lOX05BTUUgPSAnb3BlbnNlYXJjaGRhc2hib2FyZHMteGxzeC1pbXBvcnQnO1xuIl19